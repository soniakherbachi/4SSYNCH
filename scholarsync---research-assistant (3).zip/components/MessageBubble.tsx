import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Message } from '../types';
import MermaidDiagram from './MermaidDiagram';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex flex-col max-w-[95%] md:max-w-[85%] lg:max-w-[75%] ${isUser ? 'items-end' : 'items-start'}`}>
        
        {/* Avatar / Name */}
        <span className="text-xs text-slate-500 mb-1 font-medium ml-1">
          {isUser ? 'You' : 'ScholarSync AI'}
        </span>

        {/* Bubble */}
        <div
          className={`px-5 py-3.5 rounded-2xl shadow-sm text-sm md:text-base leading-relaxed transition-all overflow-hidden
            ${
              isUser
                ? 'bg-indigo-600 text-white rounded-tr-none'
                : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none shadow-sm'
            }
          `}
        >
          {message.isThinking ? (
             <div className="flex items-center space-x-2 text-indigo-200">
                <span className="animate-pulse">Searching academic databases...</span>
             </div>
          ) : (
            <div className={`markdown-body ${isUser ? 'text-indigo-50' : ''}`}>
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  code(props) {
                    const {children, className, node, ...rest} = props;
                    const match = /language-(\w+)/.exec(className || '');
                    
                    // If it's a mermaid block, render the diagram
                    if (!String(children).includes('\n') && !match) {
                       return <code {...rest} className={className}>{children}</code>
                    }

                    if (match && match[1] === 'mermaid') {
                      return (
                        <MermaidDiagram chart={String(children).replace(/\n$/, '')} />
                      );
                    }

                    return (
                      <code {...rest} className={`${className} bg-slate-100 p-1 rounded text-xs`}>
                        {children}
                      </code>
                    );
                  }
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          )}
        </div>

        {/* Sources / Grounding Data */}
        {!isUser && message.sources && message.sources.length > 0 && (
          <div className="mt-3 w-full bg-slate-50 border border-slate-200 rounded-lg p-3">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              Sources & Citations
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {message.sources.map((source, idx) => (
                <a
                  key={idx}
                  href={source.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 bg-white p-2 rounded border border-slate-100 hover:border-indigo-300 hover:shadow-sm transition-all group"
                >
                   <div className="bg-indigo-50 text-indigo-600 font-bold text-[10px] w-5 h-5 flex items-center justify-center rounded-full flex-shrink-0">
                     {idx + 1}
                   </div>
                   <span className="text-xs text-slate-600 truncate group-hover:text-indigo-700">
                     {source.title || source.uri}
                   </span>
                </a>
              ))}
            </div>
          </div>
        )}
        
        <span className="text-[10px] text-slate-400 mt-1 px-1">
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  );
};

export default MessageBubble;