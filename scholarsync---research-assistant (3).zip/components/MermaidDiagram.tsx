import React, { useEffect, useState } from 'react';
import mermaid from 'mermaid';

// Initialize mermaid settings
mermaid.initialize({
  startOnLoad: false,
  theme: 'base',
  themeVariables: {
    fontFamily: 'Inter',
    primaryColor: '#e0e7ff', // indigo-100
    primaryTextColor: '#312e81', // indigo-900
    primaryBorderColor: '#818cf8', // indigo-400
    lineColor: '#64748b', // slate-500
    secondaryColor: '#f1f5f9',
    tertiaryColor: '#fff',
  },
  securityLevel: 'loose',
});

interface MermaidDiagramProps {
  chart: string;
}

const MermaidDiagram: React.FC<MermaidDiagramProps> = ({ chart }) => {
  const [svg, setSvg] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const renderChart = async () => {
      if (!chart) return;

      try {
        setError(null);
        // Generate a unique ID for this render
        const id = `mermaid-${Math.random().toString(36).substr(2, 9)}`;
        // Mermaid v10+ returns an object with the svg property
        const { svg } = await mermaid.render(id, chart);
        setSvg(svg);
      } catch (err) {
        console.error('Mermaid render error:', err);
        setError('Failed to render diagram. The syntax might be invalid.');
      }
    };

    renderChart();
  }, [chart]);

  if (error) {
    return (
      <div className="p-3 bg-red-50 border border-red-100 rounded text-xs text-red-600 font-mono overflow-auto">
        <p className="font-bold mb-1">Diagram Error</p>
        {error}
        <pre className="mt-2 opacity-75">{chart}</pre>
      </div>
    );
  }

  if (!svg) {
    return (
      <div className="animate-pulse flex space-x-4 p-4 border rounded-lg bg-slate-50">
        <div className="flex-1 space-y-4 py-1">
          <div className="h-4 bg-slate-200 rounded w-3/4"></div>
          <div className="space-y-2">
            <div className="h-4 bg-slate-200 rounded"></div>
            <div className="h-4 bg-slate-200 rounded w-5/6"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mermaid-container w-full overflow-x-auto p-4 bg-white rounded-lg border border-slate-100 shadow-sm my-4">
      <div 
        dangerouslySetInnerHTML={{ __html: svg }} 
        className="flex justify-center min-w-[300px]"
      />
    </div>
  );
};

export default MermaidDiagram;