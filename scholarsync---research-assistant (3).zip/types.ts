import React from 'react';

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: Date;
  sources?: GroundingSource[];
  isThinking?: boolean;
}

export enum ResearchMode {
  Search = 'SEARCH',
  Methodology = 'METHODOLOGY',
  Framework = 'FRAMEWORK',
  Gaps = 'GAPS',
  DesignMap = 'DESIGN_MAP',
  Bibliometric = 'BIBLIOMETRIC'
}

export interface QuickAction {
  label: string;
  mode: ResearchMode;
  prompt: string;
  icon: React.ReactNode;
}