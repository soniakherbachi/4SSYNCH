import React, { useState, useEffect, useRef } from 'react';
import { Message, QuickAction, ResearchMode } from './types';
import { sendMessageToGemini, resetChat } from './services/geminiService';
import MessageBubble from './components/MessageBubble';
import { 
  MagnifyingGlassIcon, 
  BeakerIcon, 
  BookOpenIcon, 
  ExclamationTriangleIcon, 
  PaperAirplaneIcon,
  ArrowPathIcon,
  SparklesIcon,
  MapIcon,
  ChartBarIcon,
  ShareIcon,
  CheckIcon
} from '@heroicons/react/24/outline';

const SUGGESTED_ACTIONS: QuickAction[] = [
  {
    label: 'Methodology',
    mode: ResearchMode.Methodology,
    prompt: "Analyze the research methodologies used in these articles. Explain the study design, sampling, and data analysis techniques.",
    icon: <BeakerIcon className="w-4 h-4" />,
  },
  {
    label: 'Frameworks',
    mode: ResearchMode.Framework,
    prompt: "What theoretical or conceptual frameworks are employed in these studies? Explain how they guide the research.",
    icon: <BookOpenIcon className="w-4 h-4" />,
  },
  {
    label: 'Map Design',
    mode: ResearchMode.DesignMap,
    prompt: "Create a visual diagram (using Mermaid.js syntax) mapping the design framework or research flow for these studies. Show relationships between concepts, variables, or research phases. Use double quotes for all node labels.",
    icon: <MapIcon className="w-4 h-4" />,
  },
  {
    label: 'Bibliometric Analysis',
    mode: ResearchMode.Bibliometric,
    prompt: "Perform a bibliometric analysis for this research topic, broadening the search to other available online articles. Focus on Q1 and Q2 ranked journals. Present data in structured markdown tables for publication trends, top sources, and key keywords.",
    icon: <ChartBarIcon className="w-4 h-4" />,
  },
  {
    label: 'Research Gaps',
    mode: ResearchMode.Gaps,
    prompt: "Identify the research gaps highlighted in these articles. What limitations are mentioned, and what future research directions are suggested?",
    icon: <ExclamationTriangleIcon className="w-4 h-4" />,
  },
];

const App: React.FC = () => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasResults, setHasResults] = useState(false);
  const [showShareToast, setShowShareToast] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initial Welcome Message
  useEffect(() => {
    setMessages([
      {
        id: '1',
        role: 'model',
        content: "Hello. I am ScholarSync. \n\nEnter your research topic or keywords, and I will retrieve top academic articles (simulating Scopus/WoS indexing), analyze their methodologies, and identify research gaps for you.",
        timestamp: new Date(),
      },
    ]);
    resetChat(); // Ensure fresh session on load
  }, []);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (textOverride?: string) => {
    const textToSend = textOverride || input;
    if (!textToSend.trim() || isLoading) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: textToSend,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, newMessage]);
    setInput('');
    setIsLoading(true);

    // Add a temporary "Thinking" message
    const thinkingId = 'thinking-' + Date.now();
    setMessages((prev) => [
      ...prev,
      {
        id: thinkingId,
        role: 'model',
        content: '',
        timestamp: new Date(),
        isThinking: true,
      },
    ]);

    try {
      let prompt = textToSend;
      if (!hasResults && !textOverride) {
         prompt = `Retrieve the top 5 high-impact research articles about "${textToSend}". Focus on sources typically indexed in Scopus or Web of Science. For each, provide Title, Authors, Year, and a concise Summary.`;
      }

      const response = await sendMessageToGemini(prompt);
      
      setMessages((prev) => {
        const filtered = prev.filter(m => m.id !== thinkingId);
        return [
          ...filtered,
          {
            id: (Date.now() + 1).toString(),
            role: 'model',
            content: response.text,
            sources: response.sources,
            timestamp: new Date(),
          }
        ];
      });
      setHasResults(true);

    } catch (error) {
      setMessages((prev) => {
        const filtered = prev.filter(m => m.id !== thinkingId);
        return [
          ...filtered,
          {
            id: (Date.now() + 1).toString(),
            role: 'model',
            content: "I encountered an error while searching. Please check your connection and try again.",
            timestamp: new Date(),
          }
        ];
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleReset = () => {
    resetChat();
    setHasResults(false);
    setMessages([
        {
        id: Date.now().toString(),
        role: 'model',
        content: "Session reset. Enter a new topic to start a fresh literature review.",
        timestamp: new Date(),
      },
    ]);
  };

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
      setShowShareToast(true);
      setTimeout(() => setShowShareToast(false), 3000);
    }).catch(err => {
      console.error('Failed to copy: ', err);
    });
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50 text-slate-900 overflow-hidden font-sans">
      
      {/* Header */}
      <header className="flex-none h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 md:px-8 shadow-sm z-30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-indigo-200 shadow-lg">
            <SparklesIcon className="w-5 h-5" />
          </div>
          <h1 className="text-lg font-bold text-slate-800 tracking-tight">ScholarSync</h1>
        </div>
        
        <div className="flex items-center gap-2">
          {/* Share Button */}
          <div className="relative">
            <button 
              onClick={handleShare}
              className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 transition-all px-3 py-1.5 rounded-full hover:bg-slate-100 font-medium text-sm"
              title="Share Application"
            >
              {showShareToast ? <CheckIcon className="w-4 h-4 text-green-500" /> : <ShareIcon className="w-4 h-4" />}
              <span className="hidden sm:inline">{showShareToast ? 'Copied!' : 'Share'}</span>
            </button>
            {showShareToast && (
              <div className="absolute top-10 right-0 bg-slate-800 text-white text-[10px] px-2 py-1 rounded shadow-lg animate-fade-in-up whitespace-nowrap">
                Link copied to clipboard!
              </div>
            )}
          </div>

          <button 
            onClick={handleReset}
            className="text-slate-400 hover:text-rose-500 transition-colors p-2 rounded-full hover:bg-rose-50"
            title="Reset Session"
          >
            <ArrowPathIcon className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth">
        <div className="max-w-4xl mx-auto">
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input & Controls Area */}
      <div className="flex-none bg-white border-t border-slate-200 p-4 md:p-6 z-20">
        <div className="max-w-4xl mx-auto space-y-4">
          
          {/* Contextual Action Chips */}
          {hasResults && !isLoading && (
            <div className="flex flex-wrap gap-2 animate-fade-in-up">
              {SUGGESTED_ACTIONS.map((action) => (
                <button
                  key={action.label}
                  onClick={() => handleSendMessage(action.prompt)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 hover:border-indigo-200 border border-transparent rounded-full text-xs font-medium text-slate-600 transition-all"
                >
                  {action.icon}
                  {action.label}
                </button>
              ))}
            </div>
          )}

          {/* Input Bar */}
          <div className="relative flex items-end gap-2 bg-slate-50 border border-slate-300 rounded-xl p-2 shadow-sm focus-within:ring-2 focus-within:ring-indigo-500 focus-within:border-transparent transition-all">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder={hasResults ? "Ask a follow-up question..." : "Enter keywords (e.g., 'generative AI in education')..."}
              className="w-full bg-transparent border-none focus:ring-0 resize-none text-slate-800 placeholder-slate-400 min-h-[44px] max-h-32 py-2.5 px-2 text-sm md:text-base"
              rows={1}
              style={{ height: 'auto', minHeight: '44px' }}
              disabled={isLoading}
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={!input.trim() || isLoading}
              className={`flex-none w-10 h-10 flex items-center justify-center rounded-lg transition-all mb-[1px]
                ${(!input.trim() || isLoading) 
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
                  : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md hover:shadow-lg transform active:scale-95'}
              `}
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <PaperAirplaneIcon className="w-5 h-5" />
              )}
            </button>
          </div>
          
          <div className="text-center">
             <p className="text-[10px] text-slate-400">
               ScholarSync is an open research tool. Share the URL to invite others to research.
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;