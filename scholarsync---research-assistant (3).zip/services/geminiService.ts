import { GoogleGenAI, Chat, GroundingChunk } from "@google/genai";
import { GroundingSource } from "../types";

// Initialize API Client
// Note: process.env.API_KEY is guaranteed to be available by the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are ScholarSync, an advanced academic research assistant specializing in literature review and analysis.
Your primary goal is to assist researchers in finding high-quality academic sources (simulating Scopus/Web of Science quality), explaining complex methodologies, dissecting theoretical frameworks, and identifying critical research gaps.

Formatting Rules:
- Use Markdown for all responses.
- Use bold text for article titles and key terms.
- Use lists for clarity.
- When analyzing, be critical and academic in tone.

Search Behavior:
- When asked to find articles, use the Google Search tool to find real, existing academic papers. 
- Prioritize papers from reputable publishers (Elsevier, Springer, IEEE, Wiley, Taylor & Francis) that would typically be indexed in Scopus or Web of Science.
- Always try to provide the Title, Authors, Year, and a brief Abstract/Summary for each paper.

Analysis Behavior:
- If asked about "Methodology", explain the research design, data collection, and analysis techniques of the discussed papers.
- If asked about "Framework", identify the theoretical or conceptual frameworks used.
- If asked about "Gaps", identify limitations and areas for future research mentioned in the papers or implied by the lack of coverage.
- If asked to "Map Design Framework", you MUST generate a visual diagram using **Mermaid.js** syntax.
  - Wrap the Mermaid code in a markdown code block with the language identifier \`mermaid\`.
  - Use \`graph TD\` (top-down) or \`graph LR\` (left-right) for flowcharts.
  - Ensure node labels are concise and clear.
  - **CRITICAL**: Always wrap node labels in double quotes to prevent syntax errors. Example: A["Node Label"] --> B["Another Label"]
  - Example format:
    \`\`\`mermaid
    graph TD
      A["Concept A"] --> B["Concept B"]
      B --> C{"Decision"}
    \`\`\`
- If asked for "Bibliometric Analysis":
  - Broaden your search to find a larger set of relevant papers (beyond just the top 5) to identify trends.
  - Focus explicitly on articles likely to be in **Q1 and Q2 ranked journals** (High Impact Factor).
  - **VISUALIZATION**: You MUST present the analysis using **Structured Markdown Tables** for the following categories. Do not use simple lists for these.
    1. **Publication Trends**: 
       | Year | Number of Articles | Growth Trend |
       |------|--------------------|--------------|
       | ...  | ...                | ...          |
    2. **Top Sources**:
       | Journal Name | Publisher | Quartile (Est.) |
       |--------------|-----------|-----------------|
       | ...          | ...       | ...             |
    3. **Leading Authors**:
       | Author | Affiliation | Focus Area |
       |--------|-------------|------------|
       | ...    | ...         | ...        |
    4. **Keyword Analysis**:
       | Keyword | Frequency (Est.) | Related Themes |
       |---------|------------------|----------------|
       | ...     | ...              | ...            |
`;

let chatSession: Chat | null = null;

export const initializeChat = () => {
  chatSession = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      tools: [{ googleSearch: {} }], // Enable Google Search Grounding
    },
  });
};

export const sendMessageToGemini = async (
  message: string
): Promise<{ text: string; sources: GroundingSource[] }> => {
  if (!chatSession) {
    initializeChat();
  }

  try {
    const result = await chatSession!.sendMessage({ message });
    
    const text = result.text;
    const sources: GroundingSource[] = [];

    // Extract grounding chunks if available
    const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks;
    
    if (chunks) {
      chunks.forEach((chunk: GroundingChunk) => {
        if (chunk.web?.uri && chunk.web?.title) {
          sources.push({
            uri: chunk.web.uri,
            title: chunk.web.title
          });
        }
      });
    }

    // Remove duplicate sources based on URI
    const uniqueSources = Array.from(new Map(sources.map(item => [item.uri, item])).values());

    return { text, sources: uniqueSources };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

export const resetChat = () => {
  chatSession = null;
  initializeChat();
};